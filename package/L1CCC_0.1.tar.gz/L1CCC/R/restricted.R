## ID: restricted.R, last updated 04-23-2024, F.Osorio

restrictedFit <-
function(object) 
{ ## multivariate-Laplace restricted fitter

  ## extracting elements
  x <- object$x
  dims <- object$dims
  center <- object$center
  Scatter <- object$Scatter
  logLik <- object$logLik
  distances <- object$distances
  weights <- object$weights
  xnames <- names(object$center)

  ## some defs (FIXME)
  tol <- 1e-6
  maxiter <- 200

  n <- object$dims[1]
  p <- object$dims[2]
  storage.mode(x) <- "double"

  ## Call fitter
  now <- proc.time()
  fit <- .C("restricted_fitter",
            x = x,
            n = as.integer(n),
            p = as.integer(p),
            center = as.double(center),
            lambda = as.double(mean(center)),
            Scatter = as.double(Scatter),
            distances = double(n),
            weights = as.double(rep(1, n)),
            logLik = as.double(logLik),
            tol = as.double(tol),
            maxiter = as.integer(maxiter))
  speed <- proc.time() - now

  ## creating the output object
  out <- list(x = x,
              dims = dims,
              mean = fit$center,
              center = rep(fit$lambda, p),
              lambda = fit$lambda,
              Scatter = matrix(fit$Scatter, ncol = p),
              logLik = fit$logLik,
              numIter = fit$maxiter,
              weights = fit$weights,
              distances = fit$distances,
              speed = speed,
              converged = FALSE)
  names(out$center) <- xnames
  dimnames(out$Scatter) <- list(xnames, xnames)
  if (out$numIter < maxiter)
    out$converged <- TRUE

  class(out) <- "LaplaceFit"
  out
}
