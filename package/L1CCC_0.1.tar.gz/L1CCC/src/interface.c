/* ID: interface.c, last updated 04-23-2024, F.Osorio */

#include "base.h"
#include "interface.h"
#include <fastmatrix_API.h>

/* ========================================================================== *
 * basic matrix manipulations
 * ========================================================================== */

void
ax_plus_y(double alpha, double *x, int incx, double *y, int incy, int n)
{ /* y <- alpha * x + y */
  BLAS1_axpy(alpha, x, incx, y, incy, n);
}

void
copy_vec(double *y, int incy, double *x, int incx, int n)
{ /* y <- x (alternative to Memcpy with increments not equal to 1) */
  BLAS1_copy(y, incy, x, incx, n);
}

void
copy_lower(double *y, int ldy, double *x, int ldx, int p)
{ /* lower.tri(y) <- lower.tri(x) */
  FM_cpy_lower(x, ldx, p, y, ldy);
}

double
dot_product(double *x, int incx, double *y, int incy, int n)
{ /* sum(x * y) */
  return BLAS1_dot_product(x, incx, y, incy, n);
}

double 
logAbsDet(double *a, int lda, int n)
{ /* log(abs(det(a))) */
  return FM_logAbsDet(a, lda, n);
}

void
mult_triangular_vec(double *a, int lda, int n, char *uplo, char *trans, char *diag, double *x, int inc)
{ /* wrapper to BLAS-2 routine 'DTRMV' */
  BLAS2_trmv(a, lda, n, uplo, trans, diag, x, inc);
}

void
mult_triangular_mat(double alpha, double *a, int lda, int nrow, int ncol, char *side, char *uplo, char *trans, char *diag, double *y, int ldy)
{ /* wrapper to BLAS-3 routine 'DTRMM' */
  BLAS3_trmm(alpha, a, lda, nrow, ncol, side, uplo, trans, diag, y, ldy);
}

void
rank1_update(double *a, int lda, int nrow, int ncol, double alpha, double *x, double *y)
{ /* rank-1 update: a <- alpha * x %*% t(y) + a */
  FM_rank1_update(a, lda, nrow, ncol, alpha, x, y);
}

void
scale(double *x, int n, int inc, double alpha)
{ /* x <- alpha * x */
  BLAS1_scale(alpha, x, inc, n);
}

void
setzero(double *y, int ldy, int nrow, int ncol)
{ /* y[,] <- 0, sets all elements of y to 0 */
  FM_setzero(y, ldy, nrow, ncol);
}

/* ========================================================================== *
 * cholesky decomposition
 * ========================================================================== */

void
chol_decomp(double *a, int lda, int p, int job, int *info)
{ /* cholesky factorization of a real symmetric positive definite matrix a.
   * the factorization has the form:
   * a <- l %*% t(l) (job = 0), or a <- t(u) %*% u (job = 1),
   * where u is an upper triangular matrix and l is lower triangular */
  FM_chol_decomp(a, lda, p, job, info);
}

/* ========================================================================== *
 * multivariate sample mean
 * ========================================================================== */

void
center_online(double *x, int n, int p, double *weights, double *center)
{ /* compute center estimate using an online algorithm */
  FM_online_center(x, n, p, weights, center);
}

/* ========================================================================== *
 * Mahalanobis distance
 * ========================================================================== */

double 
mahalanobis(double *x, int p, double *center, double *Root)
{ /* Mahalanobis distance (just for a single observation), the argument 'Root'
   * corresponds to the lower triangular factor of the covariance matrix */
  return FM_mahalanobis(x, p, center, Root);
}
