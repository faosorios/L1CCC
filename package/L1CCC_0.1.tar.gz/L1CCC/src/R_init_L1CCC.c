/* ID: R_init_L1CCC.c, last updated 04-23-2024, F.Osorio */

#include "base.h"
#include <R_ext/Rdynload.h>
#include "l1ccc.h"

#define CALLDEF(name, nargs)  {#name, (DL_FUNC) &name, nargs}
#define F77DEF(name, nargs)   {#name, (DL_FUNC) &F77_NAME(name), nargs}

/* registering C and symbols */
static const R_CMethodDef CEntries[]  = {
  CALLDEF(restricted_fitter,        11),
  CALLDEF(RNG_contaminated,         7),
  {NULL, NULL, 0}
};

void R_init_L1pack(DllInfo *dll)
{
  R_registerRoutines(dll, CEntries, NULL, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
