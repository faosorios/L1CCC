/* ID: RNG.c, last updated 04-23-2024, F.Osorio */

#include "base.h"
#include "interface.h"
#include "l1ccc.h"

/* static functions.. */
static void rmcontaminated_std(double *, double, double, int, int);
/* ..end declarations */

/* ========================================================================== *
 * multivariate contaminated normal random generation
 * ========================================================================== */

void
RNG_contaminated(double *y, int *nobs, int *nvar, double *center, double *Scatter, double *eps, double *vif)
{ /* multivariate contaminated normal random generation to be called in R 
   * by 'rmcnorm' */
  char *side = "L", *uplo = "U", *trans = "T", *diag = "N";
  int info = 0, job = 1, n = *nobs, p = *nvar;

  GetRNGstate();
  chol_decomp(Scatter, p, p, job, &info);
  if (info)
    error("cholesky factorization in RNG_contaminated gave code %d", info);
  rmcontaminated_std(y, *eps, *vif, n, p);
  mult_triangular_mat(1.0, Scatter, p, p, n, side, uplo, trans, diag, y, p);
  for (int i = 0; i < n; i++) {
    ax_plus_y(1., center, 1, y, 1, p);
    y += p;
  }
  PutRNGstate();
}

static void
rmcontaminated_std(double *y, double eps, double vif, int n, int p)
{ /* spherical contaminated normal deviates */
  double radial, unif;

  radial = 1. / vif;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < p; j++)
      y[j] = norm_rand();
    unif = unif_rand();
    if (unif < eps)
      scale(y, p, 1, radial);
    y += p;
  }
}
