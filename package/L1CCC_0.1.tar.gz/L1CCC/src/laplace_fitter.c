/* ID: laplace_fitter.c, last updated 04-23-2024, F.Osorio */

#include "base.h"
#include "interface.h"
#include "l1ccc.h"

/* static functions.. */
static double do_weight(double, double);
static void E_step(double *, int, int, double *, double *, double *, double *);
static double update_lambda(int, double *, double *);
static void update_Scatter(double *, int, int, double *, double *, double *);
static double logLik_Laplace(double *, int, int, double *);
/* ..end declarations */

static double
do_weight(double length, double distance) 
{ /* multivariate Laplace weight */
  double d, ratio, wts, x;

  d = sqrt(distance);
  x = 0.5 * d;
  ratio = bessel_k(x, 0.5 * length - 1.0, 1.0) / bessel_k(x, 0.5 * length, 1.0);
  wts = 0.5 * ratio / d;

  return wts;
}

void
restricted_fitter(double *x, int *nobs, int *vars, double *center, double *lambda, double *Scatter, 
  double *distances, double *weights, double *logLik, double *tolerance, int *maxiter)
{ /* fits the multivariate Laplace model considering an unstructured covariance matrix */
  int errcode = 0, iter = 0, job = 0, n = *nobs, p = *vars, maxit = *maxiter, npars;
  double conv, fnc = *logLik, newfnc, *mean, *Root, tol = *tolerance;

  mean = (double *) Calloc(p, double);
  Root = (double *) Calloc(p * p, double);

  /* Cholesky decomposition of Scatter matrix */
  copy_lower(Root, p, Scatter, p, p);
  chol_decomp(Root, p, p, job, &errcode);
  if (errcode)
    error("Cholesky decomposition in Laplace fitter gave code %d", errcode);

  /* set elements of the restricted mean */
  for (int j = 0; j < p; j++)
    mean[j] = *lambda;
  
  /* main loop */
  repeat {
    /* E-step */
    E_step(x, n, p, mean, Root, distances, weights);

    /* M-step */
    center_online(x, n, p, weights, center);
    *lambda = update_lambda(p, center, Root);
    update_Scatter(x, n, p, weights, lambda, Scatter);

    /* 'update' mean */
    for (int j = 0; j < p; j++)
      mean[j] = *lambda;

    iter++;

    /* evaluating objective function */
    copy_lower(Root, p, Scatter, p, p);
    chol_decomp(Root, p, p, job, &errcode);
    if (errcode)
      error("Cholesky decomposition in Laplace fitter gave code %d", errcode);
    newfnc = logLik_Laplace(distances, n, p, Root);
    
    /* eval convergence */
    conv = fabs((newfnc - fnc) / (newfnc + ABSTOL));
    if (conv < tol)
      break; /* successful completion */
    if (iter >= maxit)
      break;  /* maximum number of iterations exceeded */

    fnc = newfnc;
  }

  *maxiter = iter;

  /* computation of log-likelihood function */
  copy_lower(Root, p, Scatter, p, p);
  chol_decomp(Root, p, p, job, &errcode);
  if (errcode)
    error("Cholesky decomposition in Laplace fitter gave code %d", errcode);
  *logLik = logLik_Laplace(distances, n, p, Root);

  Free(mean); Free(Root);
}

static void
E_step(double *x, int n, int p, double *center, double *Root, double *distances, double *weights)
{ /* computation of Mahalanobis distances and weights for the Laplace distribution */
  double *z;

  z = (double *) Calloc(p, double);

  for (int i = 0; i < n; i++) {
    copy_vec(z, 1, x + i, n, p);
    distances[i] = mahalanobis(z, p, center, Root);
    weights[i] = do_weight((double) p, distances[i]);
  }

  Free(z);
}

static double
update_lambda(int p, double *center, double *Root)
{ /* update lambda (common factor of the location) estimate */
  char *uplo = "L", *notrans = "N", *diag = "N";
  double lambda, *ones, *z;

  ones = (double *) Calloc(p, double);
  z    = (double *) Calloc(p, double);

  for (int j = 0; j < p; j++) {
    ones[j] = 1.0;
    z[j] = center[j];
  }

  mult_triangular_vec(Root, p, p, uplo, notrans, diag, ones, 1);
  mult_triangular_vec(Root, p, p, uplo, notrans, diag, z, 1);

  lambda  = dot_product(ones, 1, z, 1, p);
  lambda /= dot_product(ones, 1, ones, 1, p);

  Free(ones); Free(z);

  return lambda;
}

static void
update_Scatter(double *x, int n, int p, double *weights, double *lambda, double *Scatter)
{ /* compute the restricted Scatter estimate */
  double *z, wts;

  /* initialization */
  z = (double *) Calloc(p, double);
  setzero(Scatter, p, p, p);

  /* updating stage */
  for (int i = 0; i < n; i++) {
    wts = weights[i];
    copy_vec(z, 1, x + i, n, p);
    for (int j = 0; j < p; j++)
      z[j] -= *lambda;
    rank1_update(Scatter, p, p, p, wts / n, z, z);
  }
}

static double 
logLik_Laplace(double *distances, int n, int p, double *Root)
{ /* evaluate the Laplace log-likelihood */
  double accum = 0.0, val;

  /* sum the kernel of the log-density */
  for (int i = 0; i < n; i++)
    accum += sqrt(*distances++);

  val  = lgammafn(0.5 * p) - (double) p * M_LN_SQRT_PI - lgammafn((double) p) - (p + 1.0) * M_LN2;
  val -= logAbsDet(Root, p, p);
  val *= (double) n;
  val -= 0.5 * accum;

  return val;
}
