/* ID: l1ccc.h, last updated 04-23-2024, F.Osorio */

#ifndef L1CCC_H
#define L1CCC_H

#include "base.h"

/* restricted multivariate Laplace estimation */
extern void restricted_fitter(double *, int *, int *, double *, double *, double *, double *, double *, double *, double *, int *);

/* RNG for the multivariate contaminated normal distribution */
extern void RNG_contaminated(double *, int *, int *, double *, double *, double *, double *);

#endif /* L1CCC_H */
