/* ID: interface.h, last updated 04-23-2024, F.Osorio */

#ifndef L1CCC_INTERFACE_H
#define L1CCC_INTERFACE_H

/* basic matrix manipulations */
extern void ax_plus_y(double, double *, int, double *, int, int);
extern void copy_vec(double *, int, double *, int, int);
extern void copy_lower(double *, int, double *, int, int);
extern double dot_product(double *, int, double *, int, int);
extern double logAbsDet(double *, int, int);
extern void mult_triangular_vec(double *, int, int, char *, char *, char *, double *, int);
extern void mult_triangular_mat(double, double *, int, int, int, char *, char *, char *, char *, double *, int);
extern void rank1_update(double *, int, int, int, double, double *, double *);
extern void scale(double *, int, int, double);
extern void setzero(double *, int, int, int);

/* cholesky decomposition */
extern void chol_decomp(double *, int, int, int, int *);

/* descriptive statistics */
extern void center_online(double *, int, int, double *, double *);

/* Mahalanobis distance */
extern double mahalanobis(double *, int, double *, double *);

#endif /* L1CCC_INTERFACE_H */
